package Assignment2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Ellipse2D;

/* Moving ball popup - doubles as a loading screen but closes
 after player exits the end game menu or clicks "Play again".
 Designed to be eye candy until the player makes a decision*/
public class Shapes extends JPanel implements ActionListener {

    Timer tm = new Timer(5, this);
    double x = 0, y = 0,  velX = 2, velY = 2;

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        Ellipse2D circle = new Ellipse2D.Double(x, y, 40, 40);
        g2.fill(circle);
        tm.start();

    }

    // The ball will rebound indefinitely
    @Override
    public void actionPerformed(ActionEvent actionEvent) {
        if (x < 0 || x > 250) {
            velX = -velX;
        }
        if (y < 0 || y > 250) {
            velY = -velY;
        }
        x += velX;
        y += velY;
        repaint();
    }



}
