package Assignment2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class MouseClickListener implements MouseListener {

    private Game game; // Game passed through to allow for game manipulation

    public MouseClickListener(Game game) {
        this.game = game;
    }

    @Override
    public void mouseClicked(MouseEvent e) {

        for (int i = 0; i <= 8; i++) {
            game.buttons[i].setForeground(Color.WHITE);
        }
        JButton clickedButton = (JButton) e.getSource();

        // Disables buttons so symbols can't be changed
        if (!clickedButton.isEnabled()) {
            game.endGame();
            game.endGamePopup();
            return;
        }

        // Alternating turns for X & O
        while (clickedButton.isEnabled()) {
            if (game.turn % 2 == 0) {
                clickedButton.setText("X");
                clickedButton.setEnabled(false);
                game.turn += 1;
            } else {
                clickedButton.setText("O");
                clickedButton.setEnabled(false);
                game.turn += 1;
            }
        }
        game.winCondition(); // Calling the method that checks if a player has won
        this.game.repaint(); // Refreshes the game state

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
}
