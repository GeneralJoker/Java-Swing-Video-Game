package Assignment2;

import javax.swing.*;
import java.awt.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;


public class Game extends JFrame {


    JButton buttons[] = new JButton[9]; // Button array
    int turn = 0; // Counter for turns

    // Directory for text files that store wins
    String fileO = "src\\Owins.txt";
    String fileX = "src\\Xwins.txt";

    // Putting buttons on the frame
    public void initialiseButtons()
    {
        for(int i = 0; i <= 8; i++)
        {
            buttons[i] = new JButton();
            buttons[i].setText("");
            buttons[i].setBackground(Color.BLACK);
            add(buttons[i]); // Adds this to the frame
        }
    }

    // Press "SPACE" to reset the board - won't work if the board is full
    public void resetButtons()
    {
        for(int i = 0; i <= 8; i++)
        {
            buttons[i].setEnabled(true);
            buttons[i].setText("");
            buttons[i].addKeyListener(new KeyboardListener(this));
        }
    }

    // Setting all possible win conditions
    public void winCondition() {
        int[][] winningLines = {{0,1,2}, {3,4,5}, {6,7,8}, {0,3,6}, {1,4,7}, {2,5,8}, {0,4,8}, {2,4,6}};
        for (int[] line : winningLines) {
            if (
                    buttons[line[0]].getText().equals(buttons[line[1]].getText()) &&
                            buttons[line[1]].getText().equals(buttons[line[2]].getText()) &&
                            !buttons[line[0]].getText().equals("")
            ) {
                if (buttons[line[0]].getText().equals("X")) {
                    addWin(fileX); // adding a win to X
                } else if (buttons[line[0]].getText().equals("O")) {
                    addWin(fileO); // adding a win to O
                }
                // Display message for the winner and post-game events
                JOptionPane.showMessageDialog(null, "Player " + buttons[line[0]].getText() + " has won!");
                endGame();
                endGamePopup();

            }
        }
    }

    // Writing to the file that stores the wins
    private void addWin(String fileO) {
        try {
            FileWriter fw = new FileWriter(fileO, true);
            BufferedWriter bw=new BufferedWriter(fw);
            PrintWriter out = new PrintWriter(bw);
            out.write("1" + "\n");
            out.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Checking if the game has ended
    public boolean endGame() {
        boolean b = false;
        for (JButton i : buttons) {
            if (!i.isEnabled()) {
                b = true;
            }
            i.addMouseListener(new MouseClickListener(this));
        }
        return b;
    }

    // Popup if the board is filled or a player has won
    public boolean endGamePopup() {
        if (endGame()) {
            Shapes s = new Shapes();
            JFrame f = new JFrame();
            f.add(s);
            f.setSize(300, 300);
            f.setVisible(true);
            JFrame gameOver = new JFrame("Post-game");
            JButton playAgain = new JButton("Play again");
            gameOver.setSize(300, 300);
            gameOver.setDefaultCloseOperation(EXIT_ON_CLOSE);
            gameOver.add(playAgain);
            gameOver.setVisible(true);
            playAgain.addActionListener(actionEvent -> {
                f.dispose();
                dispose();
                gameOver.dispose();
                new Game(); // Restart the game
            });
        }
        return true;
    }


    public Game()  {

        // To set up the game environment
        initialiseButtons();
        resetButtons();
        winCondition();
        endGame();

        Path pathO = Paths.get(fileO);
        Path pathX = Paths.get(fileX);

        // Number of lines = Number of wins
        try {
            long winsO = Files.lines(pathO).count();
            long winsX = Files.lines(pathX).count();
            setTitle("X: " + winsX + " O: " + winsO); // Number of wins shown on the title after each new game
        } catch (IOException e) {
            e.printStackTrace();
        }

        // standard configuration
        setSize(new Dimension(400, 400));
        setLayout(new GridLayout(3,3)); // Layout for the buttons
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setVisible(true);

    }

    public static void main(String[] args) {
        new Game();
    }

}
