package Assignment2;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class KeyboardListener implements KeyListener {

    private Game game; // Game passed through to allow for game manipulation

    public KeyboardListener(Game game) {
        this.game = game;
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        switch(e.getKeyCode()) {
            case KeyEvent.VK_SPACE:
                this.game.resetButtons(); // Calling the resetsButtons() method that resets the board
                this.game.repaint();
                this.game.revalidate(); // repaints node children, rather than node
                break;
            default:
                System.out.println("Other");
                break;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {

    }
}
